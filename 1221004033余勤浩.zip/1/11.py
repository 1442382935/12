#!/usr/bin/env python3
import os
import sys
from text_classification_pipeline import GLUETextClassifier

def main():
    # 设置Windows环境变量
    os.environ['HADOOP_HOME'] = os.getcwd()
    os.environ['HADOOP_CONF_DIR'] = os.getcwd()
    
    # 创建分类器实例
    classifier = GLUETextClassifier()
    
    # 选择任务 (SST-2, CoLA, MNLI)
    task_name = "SST-2"
    print(f"开始训练 {task_name} 任务...")
    
    try:
        # 加载数据
        train_data, config = classifier.load_glue_task(task_name)
        print(f"数据加载完成，样本数: {train_data.count()}")
        
        # 数据预处理和采样
        train_data = train_data.filter(train_data.label.isNotNull())
        train_data = train_data.sample(fraction=0.5, seed=42)  # 增加到50%
        print(f"采样后样本数: {train_data.count()}")
        
        # 划分训练集和验证集
        train_df, val_df = train_data.randomSplit([0.8, 0.2], seed=42)
        print(f"训练集: {train_df.count()}, 验证集: {val_df.count()}")
        
        # 训练模型
        print("开始训练模型...")
        model = classifier.train_model(train_df)
        print("模型训练完成!")
        
        # 评估模型
        print("开始评估模型...")
        results = classifier.evaluate_model(val_df)
        print(f"验证集准确率: {results['accuracy']:.4f}")
        print(f"验证集F1分数: {results['f1_score']:.4f}")
        
        # 简化保存 - 只保存结果
        os.makedirs("results", exist_ok=True)
        with open(f"results/{task_name}_results.txt", "w") as f:
            f.write(f"Task: {task_name}\n")
            f.write(f"Accuracy: {results['accuracy']:.4f}\n")
            f.write(f"F1 Score: {results['f1_score']:.4f}\n")
            f.write(f"Training samples: {train_df.count()}\n")
            f.write(f"Validation samples: {val_df.count()}\n")
        
        print(f"结果已保存到: results/{task_name}_results.txt")
        print("训练完成！")
        
    except Exception as e:
        print(f"运行出错: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        # 停止Spark会话
        classifier.spark.stop()

if __name__ == "__main__":
    main()


