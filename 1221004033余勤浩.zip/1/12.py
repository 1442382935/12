#!/usr/bin/env python3
import os
import sys
from text_classification_pipeline import GLUETextClassifier

def main():
    print("快速测试模式 - 使用小数据集")
    classifier = GLUETextClassifier()
    
    task_name = "SST-2"
    
    try:
        # 加载并采样数据
        train_data, config = classifier.load_glue_task(task_name)
        train_data = train_data.filter(train_data.label.isNotNull())
        
        # 只使用1000条数据进行快速测试
        train_data = train_data.limit(1000)
        print(f"测试样本数: {train_data.count()}")
        
        train_df, val_df = train_data.randomSplit([0.8, 0.2], seed=42)
        
        # 训练
        print("开始快速训练...")
        model = classifier.train_model(train_df)
        
        # 评估
        results = classifier.evaluate_model(val_df)
        print(f"准确率: {results['accuracy']:.4f}")
        print(f"F1分数: {results['f1_score']:.4f}")
        
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        classifier.spark.stop()

if __name__ == "__main__":
    main()
