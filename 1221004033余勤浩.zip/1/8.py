def main():
    classifier = GLUETextClassifier()
    
    # 加载数据
    train_data, config = classifier.load_glue_task("SST-2")
    
    # 数据预处理
    train_data = train_data.filter(train_data.label.isNotNull())
    
    # 划分训练集和验证集
    train_df, val_df = train_data.randomSplit([0.8, 0.2], seed=42)
    
    # 训练模型
    model = classifier.train_model(train_df)
    
    # 评估模型
    results = classifier.evaluate_model(val_df)
    print(f"验证集准确率: {results['accuracy']:.4f}")
    print(f"验证集F1分数: {results['f1_score']:.4f}")
    
    # 保存模型
    model.write().overwrite().save("models/glue_text_classifier")

if __name__ == "__main__":
    main()