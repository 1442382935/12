#!/usr/bin/env python3
import os
import sys
from text_classification_pipeline import GLUETextClassifier

def main():
    # 创建分类器实例
    classifier = GLUETextClassifier()
    
    # 选择任务 (SST-2, CoLA, MNLI)
    task_name = "SST-2"
    print(f"开始训练 {task_name} 任务...")
    
    try:
        # 加载数据
        train_data, config = classifier.load_glue_task(task_name)
        print(f"数据加载完成，样本数: {train_data.count()}")
        
        # 数据预处理和采样（用于快速测试）
        train_data = train_data.filter(train_data.label.isNotNull())
        # 采样10%数据进行快速测试
        train_data = train_data.sample(fraction=0.1, seed=42)
        print(f"采样后样本数: {train_data.count()}")
        
        # 划分训练集和验证集
        train_df, val_df = train_data.randomSplit([0.8, 0.2], seed=42)
        print(f"训练集: {train_df.count()}, 验证集: {val_df.count()}")
        
        # 训练模型
        print("开始训练模型...")
        model = classifier.train_model(train_df)
        print("模型训练完成!")
        
        # 评估模型
        print("开始评估模型...")
        results = classifier.evaluate_model(val_df)
        print(f"验证集准确率: {results['accuracy']:.4f}")
        print(f"验证集F1分数: {results['f1_score']:.4f}")
        
        # 保存模型 - 使用try-catch处理Windows问题
        try:
            model_path = f"models/{task_name}_classifier"
            os.makedirs("models", exist_ok=True)
            model.write().overwrite().save(model_path)
            print(f"模型已保存到: {model_path}")
        except Exception as save_error:
            print(f"模型保存失败（Windows Hadoop问题）: {save_error}")
            print("但训练和评估已成功完成！")
            
            # 尝试保存为pickle格式作为备选
            try:
                import pickle
                with open(f"models/{task_name}_model_backup.pkl", "wb") as f:
                    pickle.dump(model, f)
                print(f"已保存备份模型到: models/{task_name}_model_backup.pkl")
            except Exception as pickle_error:
                print(f"备份保存也失败: {pickle_error}")
        
    except Exception as e:
        print(f"运行出错: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        # 停止Spark会话
        classifier.spark.stop()

if __name__ == "__main__":
    main()


