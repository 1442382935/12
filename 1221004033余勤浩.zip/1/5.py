import matplotlib
matplotlib.use('Agg')  # 使用非交互式后端
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

# 数据
tasks = ['SST-2', 'CoLA', 'MNLI', 'RTE']
accuracy = [76.02, 81.40, 68.45, 65.00]
f1_scores = [76.07, 78.92, 67.83, 62.15]
training_time = [3.4, 2.1, 8.7, 1.8]

fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 12))

# 1. 准确率和F1分数对比
x = np.arange(len(tasks))
width = 0.35

bars1 = ax1.bar(x - width/2, accuracy, width, label='准确率', color='#2196F3', alpha=0.8)
bars2 = ax1.bar(x + width/2, f1_scores, width, label='F1分数', color='#FF9800', alpha=0.8)

ax1.set_xlabel('GLUE任务')
ax1.set_ylabel('性能指标 (%)')
ax1.set_title('各GLUE任务性能对比')
ax1.set_xticks(x)
ax1.set_xticklabels(tasks)
ax1.legend()
ax1.grid(True, alpha=0.3)

# 添加数值标签
for bar in bars1:
    height = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., height + 0.5,
             f'{height:.1f}%', ha='center', va='bottom')

for bar in bars2:
    height = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., height + 0.5,
             f'{height:.1f}%', ha='center', va='bottom')

# 2. 训练时间对比
bars3 = ax2.bar(tasks, training_time, color=['#4CAF50', '#2196F3', '#FF5722', '#9C27B0'], alpha=0.8)
ax2.set_xlabel('GLUE任务')
ax2.set_ylabel('训练时间 (分钟)')
ax2.set_title('各任务训练时间对比')
ax2.grid(True, alpha=0.3)

for bar in bars3:
    height = bar.get_height()
    ax2.text(bar.get_x() + bar.get_width()/2., height + 0.1,
             f'{height:.1f}', ha='center', va='bottom')

# 3. 特征维度vs性能
dimensions = [2000, 5000, 10000, 20000]
performance = [74.5, 76.0, 76.8, 77.3]
memory_usage = [2.1, 4.2, 8.1, 12.5]

ax3_twin = ax3.twinx()
line1 = ax3.plot(dimensions, performance, 'o-', color='#2196F3', linewidth=2, markersize=8, label='准确率')
line2 = ax3_twin.plot(dimensions, memory_usage, 's-', color='#FF5722', linewidth=2, markersize=8, label='内存使用')

ax3.set_xlabel('特征维度')
ax3.set_ylabel('准确率 (%)', color='#2196F3')
ax3_twin.set_ylabel('内存使用 (GB)', color='#FF5722')
ax3.set_title('特征维度对性能和内存的影响')
ax3.grid(True, alpha=0.3)

# 合并图例
lines1, labels1 = ax3.get_legend_handles_labels()
lines2, labels2 = ax3_twin.get_legend_handles_labels()
ax3.legend(lines1 + lines2, labels1 + labels2, loc='center right')

# 4. 算法对比雷达图
algorithms = ['MLP', '朴素贝叶斯', '随机森林', '逻辑回归']
metrics = ['准确率', '训练速度', '内存效率', '稳定性']

# 标准化数据 (0-1)
data = np.array([
    [0.95, 0.6, 0.7, 0.9],   # MLP
    [0.85, 1.0, 1.0, 0.7],   # 朴素贝叶斯  
    [0.92, 0.4, 0.5, 0.8],   # 随机森林
    [0.90, 0.8, 0.8, 0.85]   # 逻辑回归
])

angles = np.linspace(0, 2*np.pi, len(metrics), endpoint=False).tolist()
angles += angles[:1]  # 闭合

ax4 = plt.subplot(2, 2, 4, projection='polar')
colors = ['#2196F3', '#FF9800', '#4CAF50', '#9C27B0']

for i, (algorithm, color) in enumerate(zip(algorithms, colors)):
    values = data[i].tolist()
    values += values[:1]  # 闭合
    ax4.plot(angles, values, 'o-', linewidth=2, label=algorithm, color=color)
    ax4.fill(angles, values, alpha=0.25, color=color)

ax4.set_xticks(angles[:-1])
ax4.set_xticklabels(metrics)
ax4.set_ylim(0, 1)
ax4.set_title('算法综合性能对比', pad=20)
ax4.legend(loc='upper right', bbox_to_anchor=(1.2, 1.0))

plt.tight_layout()
plt.savefig('performance_comparison.png', dpi=300, bbox_inches='tight')
print("Performance chart saved as 'performance_comparison.png'")
