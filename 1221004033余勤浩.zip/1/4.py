import matplotlib
matplotlib.use('Agg')  # 使用非交互式后端
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle

plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))

# 1. 错误类型分布
error_types = ['否定句\n误判', '讽刺\n语句', '中性\n表达', '复杂\n句式', '其他\n情况']
error_counts = [45, 38, 52, 31, 81]
error_percentages = [18.2, 15.4, 21.1, 12.6, 32.7]

colors = ['#FF5722', '#FF9800', '#FFC107', '#4CAF50', '#2196F3']
bars = ax1.bar(error_types, error_counts, color=colors, alpha=0.8)

# 添加百分比标签
for i, (bar, pct) in enumerate(zip(bars, error_percentages)):
    height = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., height + 1,
             f'{pct:.1f}%\n({height}个)', ha='center', va='bottom', fontweight='bold')

ax1.set_xlabel('错误类型')
ax1.set_ylabel('错误样本数')
ax1.set_title('SST-2任务错误类型分析')
ax1.grid(True, alpha=0.3, axis='y')

# 2. 混淆矩阵热力图
confusion_matrix = np.array([[1156, 120], [127, 1149]])
labels = ['负面', '正面']

im = ax2.imshow(confusion_matrix, interpolation='nearest', cmap='Blues')
ax2.set_title('SST-2任务混淆矩阵')

# 添加数值标签
thresh = confusion_matrix.max() / 2.
for i in range(2):
    for j in range(2):
        ax2.text(j, i, format(confusion_matrix[i, j], 'd'),
                ha="center", va="center",
                color="white" if confusion_matrix[i, j] > thresh else "black",
                fontsize=16, fontweight='bold')

ax2.set_xticks(range(2))
ax2.set_yticks(range(2))
ax2.set_xticklabels(labels)
ax2.set_yticklabels(labels)
ax2.set_xlabel('预测标签')
ax2.set_ylabel('真实标签')

# 添加颜色条
cbar = plt.colorbar(im, ax=ax2, fraction=0.046, pad=0.04)
cbar.set_label('样本数量')

# 3. 不同网络结构性能对比
structures = ['[64]', '[128,64]', '[256,128]', '[512,256]']
sst2_scores = [73.8, 75.2, 76.0, 77.1]
cola_scores = [79.4, 80.9, 81.7, 82.3]
training_times = [1.5, 2.1, 3.4, 6.8]

x = np.arange(len(structures))
width = 0.25

bars1 = ax3.bar(x - width, sst2_scores, width, label='SST-2准确率', color='#2196F3', alpha=0.8)
bars2 = ax3.bar(x, cola_scores, width, label='CoLA准确率', color='#FF9800', alpha=0.8)
bars3 = ax3.bar(x + width, training_times, width, label='训练时间(分钟)', color='#4CAF50', alpha=0.8)

ax3.set_xlabel('网络结构')
ax3.set_ylabel('性能指标')
ax3.set_title('不同MLP网络结构性能对比')
ax3.set_xticks(x)
ax3.set_xticklabels(structures)
ax3.legend()
ax3.grid(True, alpha=0.3)

# 4. 学习曲线
epochs = list(range(1, 21))
train_acc = [0.65, 0.68, 0.71, 0.73, 0.74, 0.75, 0.755, 0.758, 0.760, 0.761,
             0.762, 0.762, 0.763, 0.763, 0.763, 0.764, 0.764, 0.764, 0.764, 0.764]
val_acc = [0.63, 0.66, 0.69, 0.71, 0.72, 0.73, 0.735, 0.738, 0.740, 0.741,
           0.741, 0.740, 0.739, 0.738, 0.737, 0.736, 0.735, 0.734, 0.733, 0.732]

ax4.plot(epochs, train_acc, 'o-', label='训练集准确率', linewidth=2, markersize=4, color='#2196F3')
ax4.plot(epochs, val_acc, 's-', label='验证集准确率', linewidth=2, markersize=4, color='#FF5722')

# 标注最佳点
best_epoch = np.argmax(val_acc) + 1
best_val_acc = max(val_acc)
ax4.annotate(f'最佳: Epoch {best_epoch}\n准确率: {best_val_acc:.3f}', 
             xy=(best_epoch, best_val_acc), 
             xytext=(best_epoch+3, best_val_acc+0.01),
             arrowprops=dict(arrowstyle='->', color='red'),
             fontsize=10, color='red',
             bbox=dict(boxstyle="round,pad=0.3", facecolor='yellow', alpha=0.7))

ax4.set_xlabel('训练轮次 (Epoch)')
ax4.set_ylabel('准确率')
ax4.set_title('SST-2任务学习曲线')
ax4.legend()
ax4.grid(True, alpha=0.3)

print("Error analysis visualization saved as 'error_analysis_vitualizatign.png'")
plt.tight_layout()
plt.savefig('error_analysis_visualization.png', dpi=300, bbox_inches='tight')
print("Error analysis visualization saved as 'error_analysis_visualization.png'")




