def evaluate_model(self, test_data):
    """评估模型性能"""
    predictions = self.model.transform(test_data)
    
    evaluator = MulticlassClassificationEvaluator(
        labelCol="indexedLabel",
        predictionCol="prediction",
        metricName="accuracy"
    )
    
    accuracy = evaluator.evaluate(predictions)
    
    # F1分数评估
    f1_evaluator = MulticlassClassificationEvaluator(
        labelCol="indexedLabel",
        predictionCol="prediction", 
        metricName="f1"
    )
    f1_score = f1_evaluator.evaluate(predictions)
    
    return {"accuracy": accuracy, "f1_score": f1_score}