import matplotlib
matplotlib.use('Agg')  # 使用非交互式后端
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch
import numpy as np

plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

fig, ax = plt.subplots(1, 1, figsize=(14, 8))

# 定义颜色
colors = {
    'input': '#E3F2FD',
    'feature': '#FFF3E0', 
    'model': '#E8F5E8',
    'output': '#FCE4EC',
    'border': '#1976D2'
}

# 绘制四个主要模块
modules = [
    {'name': 'Data Input Layer', 'x': 1, 'y': 4, 'width': 2.5, 'height': 3, 'color': colors['input']},
    {'name': 'Feature Engineering', 'x': 4.5, 'y': 4, 'width': 2.5, 'height': 3, 'color': colors['feature']},
    {'name': 'Model Training', 'x': 8, 'y': 4, 'width': 2.5, 'height': 3, 'color': colors['model']},
    {'name': 'Evaluation Output', 'x': 11.5, 'y': 4, 'width': 2.5, 'height': 3, 'color': colors['output']}
]

# 绘制模块框
for module in modules:
    rect = FancyBboxPatch(
        (module['x'], module['y']), module['width'], module['height'],
        boxstyle="round,pad=0.1", 
        facecolor=module['color'],
        edgecolor=colors['border'],
        linewidth=2
    )
    ax.add_patch(rect)
    
    # 添加模块标题
    ax.text(module['x'] + module['width']/2, module['y'] + module['height'] - 0.3,
            module['name'], ha='center', va='center', fontsize=12, fontweight='bold')

# 添加子组件
components = [
    # 数据输入层
    {'text': 'GLUE Data\nLoader', 'x': 2.25, 'y': 5.5},
    {'text': 'Data Format\nUnification', 'x': 2.25, 'y': 4.8},
    
    # 特征工程层  
    {'text': 'Tokenization', 'x': 5.75, 'y': 6.2},
    {'text': 'Hash Features', 'x': 5.75, 'y': 5.6},
    {'text': 'TF-IDF', 'x': 5.75, 'y': 5.0},
    {'text': 'Label Encoding', 'x': 5.75, 'y': 4.4},
    
    # 模型训练层
    {'text': 'MLP Classifier', 'x': 9.25, 'y': 6.0},
    {'text': 'Pipeline\nTraining', 'x': 9.25, 'y': 5.2},
    {'text': 'Parameter\nOptimization', 'x': 9.25, 'y': 4.6},
    
    # 评估输出层
    {'text': 'Performance\nEvaluation', 'x': 12.75, 'y': 6.0},
    {'text': 'Result\nSaving', 'x': 12.75, 'y': 5.2},
    {'text': 'Error\nAnalysis', 'x': 12.75, 'y': 4.6}
]

for comp in components:
    ax.text(comp['x'], comp['y'], comp['text'], ha='center', va='center', 
            fontsize=10, bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8))

# 绘制箭头
arrow_props = dict(arrowstyle='->', lw=2, color=colors['border'])
ax.annotate('', xy=(4.3, 5.5), xytext=(3.7, 5.5), arrowprops=arrow_props)
ax.annotate('', xy=(7.8, 5.5), xytext=(7.2, 5.5), arrowprops=arrow_props)
ax.annotate('', xy=(11.3, 5.5), xytext=(10.7, 5.5), arrowprops=arrow_props)

# 添加Spark集群标题
ax.text(7.5, 8, 'Spark Distributed Computing Cluster', ha='center', va='center', 
        fontsize=16, fontweight='bold',
        bbox=dict(boxstyle="round,pad=0.5", facecolor='#FFEB3B', alpha=0.7))

ax.set_xlim(0, 15)
ax.set_ylim(3, 9)
ax.set_aspect('equal')
ax.axis('off')
ax.set_title('GLUE Text Classification System Architecture Based on Spark', fontsize=18, fontweight='bold', pad=20)

plt.tight_layout()
plt.savefig('system_architecture.png', dpi=300, bbox_inches='tight')
print("Architecture diagram saved as 'system_architecture.png'")
