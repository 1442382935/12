from pyspark.sql import SparkSession
from pyspark.ml.feature import Tokenizer, HashingTF, IDF, StringIndexer
from pyspark.ml.classification import MultilayerPerceptronClassifier
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.sql.functions import concat_ws

class GLUETextClassifier:
    def __init__(self):
        self.spark = SparkSession.builder \
            .appName("GLUETextClassification") \
            .config("spark.sql.adaptive.enabled", "true") \
            .config("spark.driver.memory", "8g") \
            .config("spark.executor.memory", "6g") \
            .config("spark.driver.maxResultSize", "2g") \
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true") \
            .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
            .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
            .getOrCreate()
        
        # 设置日志级别
        self.spark.sparkContext.setLogLevel("ERROR")
        self.model = None
        
    def load_glue_task(self, task_name):
        """支持多个GLUE任务"""
        task_configs = {
            "SST-2": {"text_col": "sentence", "label_col": "label", "num_classes": 2},
            "CoLA": {"text_col": "sentence", "label_col": "label", "num_classes": 2},
            "MNLI": {"text_col": ["sentence1", "sentence2"], "label_col": "gold_label", "num_classes": 3},
        }
        
        config = task_configs[task_name]
        
        # 加载训练数据
        train_df = self.spark.read.option("header", "true") \
            .option("delimiter", "\t") \
            .csv(f"glue/{task_name}/train.tsv")
            
        if task_name == "MNLI":
            # 处理句子对任务
            train_df = train_df.withColumn("sentence", 
                                         concat_ws(" [SEP] ", "sentence1", "sentence2"))
            train_df = train_df.select("sentence", "gold_label").withColumnRenamed("gold_label", "label")
        elif task_name in ["SST-2", "CoLA"]:
            train_df = train_df.select("sentence", "label")
            
        return train_df, config
    
    def build_feature_pipeline(self):
        """构建优化的特征工程管道"""
        tokenizer = Tokenizer(inputCol="sentence", outputCol="words")
        # 减少特征维度以节省内存
        hashingTF = HashingTF(inputCol="words", outputCol="rawFeatures", numFeatures=5000)
        idf = IDF(inputCol="rawFeatures", outputCol="features")
        label_indexer = StringIndexer(inputCol="label", outputCol="indexedLabel")
        
        return [tokenizer, hashingTF, idf, label_indexer]
    
    def create_mlp_model(self, input_size=5000, hidden_layers=[256, 128], num_classes=2):
        """创建更轻量的MLP模型"""
        layers = [input_size] + hidden_layers + [num_classes]
        
        mlp = MultilayerPerceptronClassifier(
            featuresCol="features",
            labelCol="indexedLabel",
            predictionCol="prediction",
            layers=layers,
            blockSize=64,  # 减小块大小
            solver="l-bfgs",
            maxIter=50,    # 减少迭代次数
            tol=1e-4,
            seed=42
        )
        return mlp
    
    def train_model(self, train_data):
        """优化的训练方法"""
        # 缓存并重分区数据
        train_data = train_data.repartition(4).cache()
        
        feature_stages = self.build_feature_pipeline()
        mlp = self.create_mlp_model()
        
        pipeline = Pipeline(stages=feature_stages + [mlp])
        self.model = pipeline.fit(train_data)
        
        # 清理缓存
        train_data.unpersist()
        return self.model
    
    def evaluate_model(self, test_data):
        """评估模型性能"""
        predictions = self.model.transform(test_data)
        
        evaluator = MulticlassClassificationEvaluator(
            labelCol="indexedLabel",
            predictionCol="prediction",
            metricName="accuracy"
        )
        accuracy = evaluator.evaluate(predictions)
        
        f1_evaluator = MulticlassClassificationEvaluator(
            labelCol="indexedLabel",
            predictionCol="prediction", 
            metricName="f1"
        )
        f1_score = f1_evaluator.evaluate(predictions)
        
        return {"accuracy": accuracy, "f1_score": f1_score}




