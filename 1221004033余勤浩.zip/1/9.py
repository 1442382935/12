def create_mlp_model(self, input_size=10000, hidden_layers=[512, 256], num_classes=2):
    """创建多层感知机模型"""
    layers = [input_size] + hidden_layers + [num_classes]
    
    mlp = MultilayerPerceptronClassifier(
        featuresCol="features",
        labelCol="indexedLabel",
        predictionCol="prediction",
        layers=layers,
        blockSize=128,
        solver="l-bfgs",
        maxIter=100,
        tol=1e-6,
        stepSize=0.03,
        seed=42
    )
    return mlp

def train_model(self, train_data):
    """训练模型"""
    # 构建完整管道
    feature_stages = self.build_feature_pipeline()
    mlp = self.create_mlp_model()
    
    pipeline = Pipeline(stages=feature_stages + [mlp])
    
    # 训练模型
    self.model = pipeline.fit(train_data)
    return self.model