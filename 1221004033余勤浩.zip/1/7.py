def load_glue_task(self, task_name):
    """支持多个GLUE任务"""
    task_configs = {
        "SST-2": {"text_col": "sentence", "label_col": "label", "num_classes": 2},
        "CoLA": {"text_col": "sentence", "label_col": "label", "num_classes": 2},
        "MNLI": {"text_col": ["sentence1", "sentence2"], "label_col": "gold_label", "num_classes": 3},
        "STS-B": {"text_col": ["sentence1", "sentence2"], "label_col": "score", "task_type": "regression"}
    }
    
    config = task_configs[task_name]
    
    if task_name == "MNLI":
        # 处理句子对任务
        train_df = self.spark.read.option("header", "true") \
            .option("delimiter", "\t") \
            .csv(f"glue/{task_name}/train.tsv")
        # 合并两个句子
        from pyspark.sql.functions import concat_ws
        train_df = train_df.withColumn("sentence", 
                                     concat_ws(" [SEP] ", "sentence1", "sentence2"))
    
    return train_df, config