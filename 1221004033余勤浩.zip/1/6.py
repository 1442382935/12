import matplotlib
matplotlib.use('Agg')  # 使用非交互式后端
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 12))

# 1. 内存使用情况
stages = ['数据\n加载', '特征\n提取', '模型\n训练', '模型\n评估', '结果\n保存']
memory_usage = [1.2, 3.8, 4.2, 3.5, 1.0]
time_points = np.arange(len(stages))

ax1.plot(time_points, memory_usage, 'o-', linewidth=3, markersize=8, color='#2196F3')
ax1.fill_between(time_points, memory_usage, alpha=0.3, color='#2196F3')
ax1.set_xlabel('训练阶段')
ax1.set_ylabel('内存使用 (GB)')
ax1.set_title('SST-2任务训练过程内存使用情况')
ax1.set_xticks(time_points)
ax1.set_xticklabels(stages)
ax1.grid(True, alpha=0.3)

# 添加峰值标注
max_idx = np.argmax(memory_usage)
ax1.annotate(f'峰值: {memory_usage[max_idx]:.1f}GB', 
             xy=(max_idx, memory_usage[max_idx]), 
             xytext=(max_idx+0.5, memory_usage[max_idx]+0.5),
             arrowprops=dict(arrowstyle='->', color='red'),
             fontsize=10, color='red')

# 2. 时间消耗分布饼图
time_components = ['特征提取', '模型训练', '数据加载', '模型评估', '其他操作']
time_percentages = [45.2, 35.8, 9.1, 4.3, 5.6]
colors = ['#FF9800', '#2196F3', '#4CAF50', '#9C27B0', '#607D8B']

wedges, texts, autotexts = ax2.pie(time_percentages, labels=time_components, colors=colors,
                                   autopct='%1.1f%%', startangle=90)
ax2.set_title('系统时间消耗分布')

# 美化饼图
for autotext in autotexts:
    autotext.set_color('white')
    autotext.set_fontweight('bold')

# 3. 不同采样比例下的性能变化
sampling_ratios = [5, 10, 15, 20, 25, 30]
sst2_acc = [73.2, 76.0, 77.1, 77.8, 78.2, 78.5]
cola_acc = [78.5, 81.4, 82.1, 82.6, 82.8, 83.0]
mnli_acc = [65.2, 68.4, 69.8, 70.5, 71.0, 71.3]
rte_acc = [62.0, 65.0, 66.5, 67.2, 67.8, 68.0]

ax3.plot(sampling_ratios, sst2_acc, 'o-', label='SST-2', linewidth=2, markersize=6)
ax3.plot(sampling_ratios, cola_acc, 's-', label='CoLA', linewidth=2, markersize=6)
ax3.plot(sampling_ratios, mnli_acc, '^-', label='MNLI', linewidth=2, markersize=6)
ax3.plot(sampling_ratios, rte_acc, 'd-', label='RTE', linewidth=2, markersize=6)

ax3.set_xlabel('采样比例 (%)')
ax3.set_ylabel('准确率 (%)')
ax3.set_title('不同采样比例下的性能变化趋势')
ax3.legend()
ax3.grid(True, alpha=0.3)

# 4. 扩展性测试结果
data_sizes = [1, 5, 10, 20]  # 万条
processing_times = [1.2, 3.4, 8.7, 18.2]
accuracies = [74.5, 76.0, 76.8, 77.2]
efficiency = [1.0, 0.71, 0.55, 0.46]

ax4_twin = ax4.twinx()
ax4_twin2 = ax4.twinx()
ax4_twin2.spines['right'].set_position(('outward', 60))

line1 = ax4.bar([x-0.2 for x in data_sizes], processing_times, width=0.4, 
                color='#FF5722', alpha=0.7, label='处理时间')
line2 = ax4_twin.plot(data_sizes, accuracies, 'go-', linewidth=2, markersize=8, label='准确率')
line3 = ax4_twin2.plot(data_sizes, efficiency, 'bs-', linewidth=2, markersize=8, label='扩展效率')

ax4.set_xlabel('数据规模 (万条)')
ax4.set_ylabel('处理时间 (分钟)', color='#FF5722')
ax4_twin.set_ylabel('准确率 (%)', color='green')
ax4_twin2.set_ylabel('扩展效率', color='blue')
ax4.set_title('数据规模扩展性测试')

# 合并图例
lines1, labels1 = ax4.get_legend_handles_labels()
lines2, labels2 = ax4_twin.get_legend_handles_labels()
lines3, labels3 = ax4_twin2.get_legend_handles_labels()
ax4.legend(lines1 + lines2 + lines3, labels1 + labels2 + labels3, loc='upper left')

plt.tight_layout()
plt.savefig('training_process_analysis.png', dpi=300, bbox_inches='tight')
print("Training process analysis chart saved as 'training_process_analysis.png'")


