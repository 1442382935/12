def build_feature_pipeline(self):
    """构建特征工程管道"""
    # 文本分词
    tokenizer = Tokenizer(inputCol="sentence", outputCol="words")
    
    # 特征哈希
    hashingTF = HashingTF(inputCol="words", outputCol="rawFeatures", 
                         numFeatures=10000)
    
    # TF-IDF
    idf = IDF(inputCol="rawFeatures", outputCol="features")
    
    # 标签编码
    label_indexer = StringIndexer(inputCol="label", outputCol="indexedLabel")
    
    return [tokenizer, hashingTF, idf, label_indexer]