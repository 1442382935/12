#!/usr/bin/env python3
import os
import sys
from text_classification_pipeline import GLUETextClassifier

def test_task(task_name):
    print(f"\n=== 测试 {task_name} 任务 ===")
    classifier = GLUETextClassifier()
    
    try:
        # 加载数据
        train_data, config = classifier.load_glue_task(task_name)
        train_data = train_data.filter(train_data.label.isNotNull())
        train_data = train_data.sample(fraction=0.05, seed=42)  # 更小的采样
        
        print(f"采样后样本数: {train_data.count()}")
        
        # 划分数据
        train_df, val_df = train_data.randomSplit([0.8, 0.2], seed=42)
        
        # 训练
        model = classifier.train_model(train_df)
        
        # 评估
        results = classifier.evaluate_model(val_df)
        print(f"{task_name} - 准确率: {results['accuracy']:.4f}, F1: {results['f1_score']:.4f}")
        
        return results
        
    except Exception as e:
        print(f"{task_name} 测试失败: {e}")
        return None
    finally:
        classifier.spark.stop()

def main():
    tasks = ["SST-2", "CoLA"]  # 先测试这两个
    results = {}
    
    for task in tasks:
        result = test_task(task)
        if result:
            results[task] = result
    
    print("\n=== 所有任务结果 ===")
    for task, result in results.items():
        print(f"{task}: 准确率={result['accuracy']:.4f}, F1={result['f1_score']:.4f}")

if __name__ == "__main__":
    main()